"use strict";
exports.__esModule = true;
var EthereumAccount_1 = require("./EthereumAccount");
var account = new EthereumAccount_1.EthereumAccount();
account.getBalance().then(function (response) { return console.log(response); });
